export default function Obrigado() {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>✅ Pagamento confirmado!</h1>
      <p>Seu acesso ao curso <b>Crescendo pra Vencer</b> foi liberado.</p>
      <p>Confira seu e-mail para receber os dados de login.</p>
    </div>
  );
}
