import { useState } from "react";

export default function Home() {
  const [loading, setLoading] = useState(false);

  async function handleCheckout() {
    setLoading(true);
    const res = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/api/checkout`, {
      method: "POST",
    });
    const data = await res.json();
    window.location.href = data.url;
  }

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h1>Crescendo pra Vencer</h1>
      <p>Curso exclusivo por apenas R$22,00</p>
      <button
        onClick={handleCheckout}
        disabled={loading}
        style={{ padding: "12px 24px", fontSize: "18px", cursor: "pointer" }}
      >
        {loading ? "Carregando..." : "Comprar com Pix"}
      </button>
    </div>
  );
}
