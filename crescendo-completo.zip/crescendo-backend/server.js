import express from "express";
import Stripe from "stripe";
import bodyParser from "body-parser";
import cors from "cors";

const app = express();
app.use(cors());
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Rota para criar o checkout Pix
app.post("/api/checkout", async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["pix"],
      line_items: [
        {
          price: process.env.STRIPE_PRICE_ID,
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: "https://SEU-FRONTEND.vercel.app/obrigado",
      cancel_url: "https://SEU-FRONTEND.vercel.app",
    });

    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Webhook de confirmação
app.post("/webhook", bodyParser.raw({ type: "application/json" }), (req, res) => {
  const sig = req.headers["stripe-signature"];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    console.log("Pagamento confirmado para:", session.customer_email);
    // Aqui você libera o curso no banco de dados ou envia acesso
  }

  res.json({ received: true });
});

app.listen(4000, () => console.log("Backend rodando na porta 4000"));
